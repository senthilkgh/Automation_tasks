# Ansible Kernel Cleanup Playbook
## RHEL / CentOS / AlmaLinux / Rocky Linux — All Versions

---

## What This Playbook Does

| Action | Detail |
|--------|--------|
| ✅ Keeps | Running kernel only (`uname -r`) — dynamically detected per host |
| ❌ Removes | All older kernel packages (kernel, kernel-core, kernel-modules, etc.) |
| ❌ Removes | All debug kernel packages (kernel-debug, kernel-debug-core, etc.) |
| 🛡️ Safety | Hard abort if running kernel appears in removal list |
| 📝 Logs | `/var/log/ansible_kernel_cleanup.log` on each target host |

---

## Files

```
kernel_cleanup.yml   ← Main playbook
inventory.ini        ← Host inventory (edit this)
ansible.cfg          ← Ansible config (project-level)
README.md            ← This file
```

---

## Prerequisites

**On the control node (where you run Ansible):**
```bash
pip install ansible        # Ansible 2.9+
ansible --version          # verify
```

**On target servers:**
- SSH access with a service account
- `sudo` privileges for that account (passwordless preferred)
- Python 3.x installed (usually present on RHEL 7+)

---

## Setup

### 1. Edit `inventory.ini`
Replace the example hostnames with your actual servers:
```ini
[rhel_prod]
your-server-01.domain.com ansible_user=ansible_svc
your-server-02.domain.com ansible_user=ansible_svc
```

### 2. Set up SSH key authentication
```bash
# Generate a dedicated key (if you don't have one)
ssh-keygen -t rsa -b 4096 -f ~/.ssh/ansible_id_rsa -C "ansible-kernel-cleanup"

# Copy to each target server
ssh-copy-id -i ~/.ssh/ansible_id_rsa.pub ansible_svc@your-server-01.domain.com
```

### 3. Configure passwordless sudo on target servers
Add to `/etc/sudoers.d/ansible_svc`:
```
ansible_svc ALL=(ALL) NOPASSWD: ALL
```

---

## Usage

### Dry Run (recommended first)
Simulates the playbook — shows what WOULD be removed without making changes:
```bash
ansible-playbook kernel_cleanup.yml --check
```

Or use the built-in dry_run variable:
```bash
ansible-playbook kernel_cleanup.yml -e "dry_run=true"
```

### Live Run — All Hosts
```bash
ansible-playbook kernel_cleanup.yml
```

### Run on Specific Group
```bash
ansible-playbook kernel_cleanup.yml -l rhel_prod
ansible-playbook kernel_cleanup.yml -l rhel_staging
```

### Run on a Single Host
```bash
ansible-playbook kernel_cleanup.yml -l prod-app-01.example.com
```

### Verbose Output (for troubleshooting)
```bash
ansible-playbook kernel_cleanup.yml -vv
```

### With sudo password (if passwordless sudo not configured)
```bash
ansible-playbook kernel_cleanup.yml --ask-become-pass
```

---

## Example Output

```
PLAY [RHEL Kernel Cleanup] *************************************

TASK [Get currently running kernel]
ok: [prod-app-01] => Running kernel: 4.18.0-553.123.1.el8_10.x86_64

TASK [Display all installed kernel packages]
ok: [prod-app-01] =>
  All installed kernel-related packages:
    kernel-4.18.0-553.117.1.el8_10.x86_64
    kernel-4.18.0-553.123.1.el8_10.x86_64    ← will KEEP
    kernel-core-4.18.0-553.117.1.el8_10.x86_64
    kernel-core-4.18.0-553.123.1.el8_10.x86_64
    kernel-debug-4.18.0-553.117.1.el8_10.x86_64

TASK [Show kernels marked for removal]
ok: [prod-app-01] =>
  KEEP  (running): kernel-4.18.0-553.123.1.el8_10.x86_64
  REMOVE (3 packages):
    kernel-4.18.0-553.117.1.el8_10.x86_64
    kernel-core-4.18.0-553.117.1.el8_10.x86_64
    kernel-debug-4.18.0-553.117.1.el8_10.x86_64

TASK [Safety check - confirm running kernel is NOT in removal list]
ok: [prod-app-01] => Safety check passed - running kernel is safe.

TASK [Remove old and debug kernel packages]
changed: [prod-app-01]

╔══════════════════════════════════════════════════╗
║  KERNEL CLEANUP SUMMARY - prod-app-01            ║
║  OS           : RedHat 8.10                      ║
║  Kernel kept  : 4.18.0-553.123.1.el8_10.x86_64  ║
║  Pkgs removed : 3                                ║
║  Debug kernels: REMOVED                          ║
║  Final state  : 2 kernel package(s) remain       ║
╚══════════════════════════════════════════════════╝
```

---

## RHEL Version Compatibility

| RHEL Version | Package Manager | Supported |
|--------------|-----------------|-----------|
| RHEL 6       | yum             | ✅ |
| RHEL 7       | yum             | ✅ |
| RHEL 8       | dnf             | ✅ |
| RHEL 9       | dnf             | ✅ |
| CentOS 7/8   | yum/dnf         | ✅ |
| AlmaLinux 8/9| dnf             | ✅ |
| Rocky Linux 8/9| dnf           | ✅ |

---

## Security Notes

- The playbook **never removes the currently running kernel** (hard safety assertion)
- Removing old kernels eliminates unpatched kernel CVEs from the package database
- Debug kernels are removed as they expose additional kernel internals
- A reboot is **not required** — the running kernel remains active
- Kernel headers (`kernel-headers`) are intentionally left as they may be needed by dkms/build tools

---

## Troubleshooting

**"sudo: a password is required"**  
→ Add `--ask-become-pass` flag or configure passwordless sudo

**"Permission denied (publickey)"**  
→ Ensure SSH key is copied: `ssh-copy-id -i ~/.ssh/ansible_id_rsa.pub user@host`

**Playbook aborts at safety check**  
→ This is intentional — contact the author; do not override this check

**"Python not found"**  
→ Set `ansible_python_interpreter=/usr/bin/python` in inventory vars (RHEL 6)
